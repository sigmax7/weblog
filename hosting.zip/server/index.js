import bodyParser from "body-parser";
import express from "express";
const app = express();
const port = 4000;

app.listen(port , () => {
    console.log(`Server started on port ${port}`);
});

app.use(express.static("public"));
app.use(bodyParser.urlencoded({extended : true}));

app.get("/",(req,res) => {
    res.render("index.ejs");
});

app.get("/create.ejs" ,(req,res) => {
    res.render("create.ejs");
});

app.get("/about.ejs",(req,res) => {
    res.render("about.ejs");
});

app.get("/contact.ejs",(req,res) => {
    res.render("contact.ejs");
});

app.get("/Signin.ejs",(req,res) => {
    res.render("signin.ejs");
});

app.get("/signup.ejs",(req,res) => {
    res.render("signup.ejs");
});

app.post("/submitpost",(req, res) => {
    const data = req.body["post"];
    res.render("postview.ejs",{datas : data})
});

app.get("/modify.ejs",(req,res) => {
    res.render("modify.ejs");
});

app.get("/profile.ejs",(req,res) => {
    res.render("profile.ejs");
});

app.post("/modsubmit",(req,res) => {
    const dataz = req.body["text"];
    res.render("postview.ejs",{datas : dataz});
});

// app.get("/postview.ejs",(req,res) => {
//     const data = req.body["post"]
//     res.render("postview.ejs",{datas : post});
// });
